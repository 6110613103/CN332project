/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bubletae;

import java.util.Scanner;

/**
 *
 * @author noeyyeon
 */
public class Bubble implements Eliment {

    @Override
    public void select() {
        Scanner tea = new Scanner(System.in);
        System.out.println("Select Bubble");
        System.out.println("1. No Bubble");
        System.out.println("2. Bubble");
        
        String order = tea.nextLine();  // Read user input
        System.out.println("Your tea is : " + order);  // Output user input
    }
    
}
