/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bubletae;

import java.util.Scanner;

/**
 *
 * @author noeyyeon
 */
public class Tea implements Eliment {

    @Override
    public void select() {
        Scanner tea = new Scanner(System.in);
        System.out.println("Select your Tea");
        System.out.println("1. Thai Tea");
        System.out.println("2. Taiwan Tea");
        System.out.println("3. CoCo");
        
        String order = tea.nextLine();  // Read user input
        System.out.println("Your tea is : " + order);  // Output user input
        
    }
}
